from flask import *
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/document'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

@app.route('/login')
def login():
	return render_template("login.html")
@app.route('/dev')
def dev():
	return render_template("dev.html")
@app.route('/register')
def register():
	return render_template("register.html")	
@app.route('/pm')	
def pm():
	return render_template("pm.html")
@app.route('/pm2')
def pm2():
	return render_template("pm2.html")	
@app.route('/tm')
def tm():
	return render_template("tm.html")
@app.route('/tm1')
def tm1():
	return render_template("tm1.html")

class register(db.Model):
	id = db.Column('register_id', db.Integer, primary_key = True )
	e_name=db.Column(db.String(50))
	e_number=db.Column(db.Integer)



						
if __name__ =='__main__':
	app.run()
	

